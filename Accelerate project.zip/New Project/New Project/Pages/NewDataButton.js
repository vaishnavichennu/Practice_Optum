﻿function new_data_handler() {
    alert('Button Clicked');
}
