﻿using Microsoft.EntityFrameworkCore;
using Patient.Data;

namespace New_Project.Pages
{
    public class PatientDrugDetailsDbContext: DbContext
    {
        public virtual DbSet<PatientDrugDetails> PatientDrugDetails { get; set; }
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                optionsBuilder.UseSqlServer(@"Data Source=LHTU05CG2124QL6;Initial Catalog=Accelerate;Integrated Security=True");
            }
        }
    }
}
