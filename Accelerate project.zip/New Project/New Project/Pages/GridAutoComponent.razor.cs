﻿using Microsoft.AspNetCore.Components;

namespace New_Project.Pages
{
    public partial class GridAutoComponent
    {

        [Parameter]
        public List<master> Items { get; set; }

    }
}
