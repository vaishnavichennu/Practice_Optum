﻿namespace New_Project.Pages
{
    public class master
    {
    
            public int Id { get; set; }
            public string OriginalProduct { get; set; }
            public string ReplacementProduct { get; set; }
            public int OriginalPackSize { get; set; }

    }
}
