﻿using NPOI.SS.UserModel;
using System.Data;
using System.IO;
using NPOI.XSSF.UserModel;
using NPOI.SS.UserModel;
using System.Data.SqlClient;
using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Components.Forms;
using Patient.Data;

namespace New_Project.Pages
{
    public class FileUpload1Base: ComponentBase
    {
        public DataTable dt = new DataTable();


        public async void PushData(List<PatientDrugDetails> PatientDrugDetailsData)
        {
            PatientDrugDetailsDbContext PatientContext = new PatientDrugDetailsDbContext();
            PatientContext.PatientDrugDetails.AddRangeAsync(PatientDrugDetailsData);
            PatientContext.SaveChanges();

        }

        public async Task ImportExcelFile(InputFileChangeEventArgs e)
        {
            dt = await ReadExcelData(e);
            List<PatientDrugDetails> PatientTable = MapPatientData(dt);
            PushData(PatientTable);
            
        }

        public async Task<DataTable> ReadExcelData(InputFileChangeEventArgs e)
        {
            DataTable ExcelData = new DataTable();
            var fileStream = e.File.OpenReadStream();
            var ms = new MemoryStream();
            await fileStream.CopyToAsync(ms);
            fileStream.Close();
            ms.Position = 0;

            ISheet sheet;
            var xswwb = new NPOI.XSSF.UserModel.XSSFWorkbook(ms);
            sheet = xswwb.GetSheetAt(0);
            IRow hr = sheet.GetRow(0);
            var rl = new List<string>();

            int cc = hr.LastCellNum;
            for (var j = 0; j < cc; j++)
            {
                ICell cell = hr.GetCell(j);
                ExcelData.Columns.Add(cell.ToString());
            }

            for (var j = (sheet.FirstRowNum + 1); j <= sheet.LastRowNum; j++)
            {
                var r = sheet.GetRow(j);
                for (var i = r.FirstCellNum; i < cc; i++)
                {
                    rl.Add(r.GetCell(i).ToString());
                }

                if (rl.Count > 0)
                {
                    ExcelData.Rows.Add(rl.ToArray());
                }
                rl.Clear();
            }
            return ExcelData;
        }
        private List<PatientDrugDetails> MapPatientData(DataTable dt)
        {

            //var convertedList = (from rw in dt.AsEnumerable()
            //                     select new PatientInfo() { Id = Convert.ToInt32(rw["Id"]), 
            //                         Patient_Id = 123, 
            //                         Dispensing = Convert.ToBoolean(rw["Dispensing"]), 
            //                         GP_Name = Convert.ToString(rw["GP_Name"]), 
            //                         Drug_Name = Convert.ToString(rw["Drug_Name"]), 
            //                         Date_Of_Issue = Convert.ToDateTime(rw["Date_Of_Issue"]), 
            //                         No_Of_Packs = Convert.ToInt32(rw["No_Of_Packs"]),
            //                         }).ToList();
            List<PatientDrugDetails> list = new List<PatientDrugDetails>();
            foreach(var rw in dt.AsEnumerable())
            {
                list.Add(new PatientDrugDetails()
                {
                    Patient_Id = Int32.Parse(Convert.ToString(rw["EMIS Number"])),
                    Dispensing = Convert.ToBoolean(rw["Dispensing Patient"]),
                    GP_Name = Convert.ToString(rw["Usual GP's Full Name"]),
                    Dose = Convert.ToString(rw["Dose"]),
                    Quantity = float.Parse(Convert.ToString(rw["Quantity"])),
                    Drug_Name = Convert.ToString(rw["Name, Dosage and Quantity"]),
                    Date_Of_Issue = Convert.ToDateTime(rw["Date of Issue"]),
                });
            }
            return list;
            //return convertedList;
        }
    }
}

