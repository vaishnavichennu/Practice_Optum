﻿using Microsoft.AspNetCore.Components;
namespace New_Project.Pages
{
    public class IndexBase: ComponentBase
    {
        public List<master> masters { get; set; } = new List<master>()
        {
            new master { Id = 1, OriginalProduct = "Acetylcysteine 600mg", ReplacementProduct = "NACSYS 600mg effervescent", OriginalPackSize = 30 },
            new master { Id = 2, OriginalProduct = "Cetirizine 10mg tablets", ReplacementProduct = "Test", OriginalPackSize = 45 },
            new master { Id = 3, OriginalProduct = "Ezetrol 10mg tablets", ReplacementProduct = "Pregabalin 100mg capsules", OriginalPackSize = 51 }

        };

//protected async override Task OnInitialisedAsync()
//        {


//            masters = new List<master>(){
//            new master { Id = 1, OriginalProduct = "Acetylcysteine 600mg", ReplacementProduct = "NACSYS 600mg effervescent", OriginalPackSize = 30 },
//            new master { Id = 2, OriginalProduct = "Cetirizine 10mg tablets", ReplacementProduct = "Test", OriginalPackSize = 45 },
//            new master { Id = 3, OriginalProduct = "Ezetrol 10mg tablets", ReplacementProduct = "Pregabalin 100mg capsules", OriginalPackSize = 51 }

//  };
//            StateHasChanged();

//            return new Task(Task.CompletedTask);
//        }

    }
}
