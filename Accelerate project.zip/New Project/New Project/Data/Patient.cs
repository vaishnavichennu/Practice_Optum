﻿
using System.ComponentModel.DataAnnotations;

namespace Patient.Data
{
    public class PatientDrugDetails
    {
        [Key]
        public int Patient_Id { get; set; }

        public bool Dispensing { get; set; }

        public string GP_Name{ get; set; }

        public string Drug_Name { get; set; }

        public DateTime Date_Of_Issue { get; set; }
        public string Dose { get; set; }
        public float Quantity { get; set; }

        public int Practise_Id { get; set; } = 123;
        public int Clinical_System_Id { get; set; } = 321;
        public int Report_Created_By { get; set; } = 45;
        public DateTime Report_Created_date { get; set; } = DateTime.Now;
        public int Report_Upload_By { get; set; } = 54;
        public DateTime Report_Uploaded_Date { get; set; } = DateTime.UtcNow;

    }
}



